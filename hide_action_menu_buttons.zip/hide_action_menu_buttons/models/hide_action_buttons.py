# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from odoo import api, fields, models


class hiHdeActionButtos(models.Model):
    _name = 'hide.action.buttons'
    model_names = fields.Char(string="Model name")

    @api.model
    def check_if_group_view(self,*args, **kwargs):

        if self.env.user.has_group('hide_action_menu_buttons.group_allow_to_see_action_button') :
            return True
        else:
            return  False